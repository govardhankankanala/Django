from django.shortcuts import render, redirect
from django.contrib.auth.models import User, auth
from django.contrib import messages

# Create your views here.
def register(request):

    if request.method == 'POST':
       first_name = request.POST['firstname']
       last_name = request.POST['lastname']
       username = request.POST['username']
       password1 = request.POST['psw']
       password2 = request.POST['psw-repeat']
       email = request.POST['email']

       if password1 == password2:
           if User.objects.filter(username=username).exists():
               print('user Already Exists')
               messages.info(request,'Usrname Taken')
               return redirect('register')
           elif User.objects.filter(email=email).exists():
               print('Email Already Exists')
               messages.info(request,'Email Taken')
               return redirect('register')

           
       else:
           print('password Not match')
           #messages.info(request,'Password not match')
           messages.warning(request, 'Please correct the error below.')
           return redirect('register')


       user = User.objects.create_user(username=username, password=password1, email=email, first_name=first_name, last_name=last_name)
       user.save();
       print('user created')
       return redirect('/')
    else:

     return render(request,"register.html")