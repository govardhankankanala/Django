from django.shortcuts import render


# Create your views here.
from django.http import HttpResponse
from .models import Destination

# Create your views here.
def index(request):
    dest1 = Destination()
    dest1.name = 'PyAdmin'
    dest1.id = '12292019'
    dest1.desc = 'PyAdmin is Programing language'
    dest1.img = 'blog-01.jpg'

    dest2 = Destination()
    dest2.name = 'Linux'
    dest2.id = '13292019'
    dest2.desc = 'Linux is OS'
    dest2.img = 'blog-02.jpg'

    dest3 = Destination()
    dest3.name = 'AWS'
    dest3.id = '14292019'
    dest3.desc = 'AWS is Cloud'
    dest3.img = 'blog-03.jpg'

    dests = [dest1,dest2,dest3]
    return render(request, "index.html", {'dests': dests})