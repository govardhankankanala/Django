from django.apps import AppConfig


class TravelapConfig(AppConfig):
    name = 'travelap'
