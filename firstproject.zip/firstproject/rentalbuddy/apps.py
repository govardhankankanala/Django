from django.apps import AppConfig


class RentalbuddyConfig(AppConfig):
    name = 'rentalbuddy'
